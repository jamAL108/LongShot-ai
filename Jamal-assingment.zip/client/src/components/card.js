const card=[
    {
        heading:"About Taylor swift",
        subhead:"know about Swift",
        query:"who is taylor swift , tell about about her."
    },
    {
        heading:"ICC WORLD CUP 2023",
        subhead:"Know information about WC 2023",
        query:"who is taylor swift , tell about about her."
    },
    {
        heading:"About Taylor swift",
        subhead:"know about Swift",
        query:"who is taylor swift , tell about about her."
    },
    {
        heading:"About Taylor swift",
        subhead:"know about Swift",
        query:"who is taylor swift , tell about about her."
    }
]

export default card
